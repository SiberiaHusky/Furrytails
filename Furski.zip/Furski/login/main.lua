-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()
secondary = themeUtil.getColorSecondary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "login/layout"

-- 设置布局
activity.setContentView(loadlayout("login/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
local window = activity.getWindow()
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

-- Toolbar 菜单
local navigationMenu = toolbar.menu

import "iconDrawable"

navigationMenu.add(0,0,0,text_open_in_browser).setIcon(iconDrawable("open_in_browser_black_24dp.png")).setShowAsAction(2)

local appName = this.getPackageManager().getApplicationLabel(this.getPackageManager().getApplicationInfo(this.getPackageName(),0))

toolbar.setOnMenuItemClickListener(OnMenuItemClickListener{
  onMenuItemClick=function(item)
    openInBrowser("https://"..readData("site").."/session/new")
  end
})

toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}

local texts_login_tips_processed = string.gsub(texts_login_tips, "%%s", readData("site"))
textLoginTips.Text = texts_login_tips_processed

cjson = import "cjson"

progressbar.IndeterminateDrawable.setColorFilter(PorterDuffColorFilter(backgroundc, PorterDuff.Mode.SRC_ATOP))

function login(username, apikey)
  transparencyAnimation(textLogin, 200, 1, 0)

  progressbar.setVisibility(0)
  transparencyAnimation(progressbar, 200, 0, 1)

  task(200, function()
    textLogin.setVisibility(4)
  end)

  Http.get("https://"..readData("site").."/posts.json?login="..username.."&api_key="..apikey, nil, "utf-8", nil, function(code, content)
    if code == 200 then
      local content = cjson.decode(content)

      if content.success == nil then
        transparencyAnimation(progressbar, 200, 1, 0)

        textLogin.Text = text_logged
        textLogin.setVisibility(0)
        transparencyAnimation(textLogin, 200, 0, 1)

        task(200, function()
          progressbar.setVisibility(4)
        end)

        saveData("username", username)
        saveData("apikey", apikey)

        local texts_login_success_processed = string.gsub(texts_login_success, "%%s", username)

        local anchor=activity.findViewById(android.R.id.content)
        Snackbar.make(anchor, texts_login_success_processed, Snackbar.LENGTH_SHORT).show()

      end

     elseif code == 401 then
      transparencyAnimation(progressbar, 200, 1, 0)
      textLogin.setVisibility(0)
      transparencyAnimation(textLogin, 200, 0, 1)

      task(200, function()
        progressbar.setVisibility(4)
      end)

      local error_login_wrong_processed = string.gsub(error_login_wrong, "%%s", code)

      local anchor=activity.findViewById(android.R.id.content)
      Snackbar.make(anchor, error_login_wrong_processed, Snackbar.LENGTH_SHORT).show()

     else
      transparencyAnimation(progressbar, 200, 1, 0)
      textLogin.setVisibility(0)
      transparencyAnimation(textLogin, 200, 0, 1)

      task(200, function()
        progressbar.setVisibility(4)
      end)

      local error_login_processed = string.gsub(error_login, "%%s", code)

      local anchor=activity.findViewById(android.R.id.content)
      Snackbar.make(anchor, error_login_processed, Snackbar.LENGTH_SHORT).show()

    end
  end)
end

cardLogin.onClick = function()
  if #editUsername.Text == 0 then
    editUsername.setError(error_username_blank)

   elseif #editApikey.Text == 0 then
    editApikey.setError(error_apikey_blank)

   else
    if editUsername.Text:find("%s") then
      editUsername.setError(error_username_space)

     elseif editApikey.Text:find("%s") then
      editApikey.setError(error_apikey_space)

     else
      login(editUsername.Text, editApikey.Text)

    end

  end
end

local isPasswordVisible = editApikey.getInputType() == InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD

cardEditPassword.onClick = function()
  local isPasswordVisible = editApikey.getInputType() == InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD

  if isPasswordVisible then
    Glide.with(this).load(activity.getLuaDir().."/res/visible_black_24dp.png").into(imageEditPassword)
    editApikey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)
   else
    Glide.with(this).load(activity.getLuaDir().."/res/invisible_black_24dp.png").into(imageEditPassword)
    editApikey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
  end
end

if isPasswordVisible then
  Glide.with(this).load(activity.getLuaDir().."/res/visible_black_24dp.png").into(imageEditPassword)
 else
  Glide.with(this).load(activity.getLuaDir().."/res/invisible_black_24dp.png").into(imageEditPassword)
end