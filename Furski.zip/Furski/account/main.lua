-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()
secondary = themeUtil.getColorSecondary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "account/layout"

-- 设置布局
activity.setContentView(loadlayout("account/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
local window = activity.getWindow()
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

refreshLayout.setColorSchemeColors{primaryc}
refreshLayout.setProgressBackgroundColorSchemeColor(backgroundc)

-- 用户名
if isLogged() then
  textUsername.Text = readData("username")

 else
  textUsername.Text = text_login
  cardLogout.setVisibility(8)

end

if readData("site") == nil then
  saveData("site", "e926.net")

 else
  textSite.Text = readData("site")

  if readData("site") == "e926.net" then
    switchSite.setChecked(false)

   elseif readData("site") == "e621.net" then
    switchSite.setChecked(true)

   else
    switchSite.setEnabled(false)

  end

end

toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}

cardAccount.onClick = function()
  activity.newActivity("login")
end

switchSite.setOnCheckedChangeListener{
  onCheckedChanged=function(g,c)
    if c == true then
      textSite.Text = "e621.net"
      saveData("site", "e621.net")

     else
      textSite.Text = "e926.net"
      saveData("site", "e926.net")

    end
  end
}

cardLogout.onClick = function()
  if isLogged() then
    dialog = MaterialAlertDialogBuilder(this)
    .setTitle(text_sign_out)
    .setMessage(texts_sign_out)
    .setPositiveButton(text_confirm, function()
      local texts_logged_out_processed = string.gsub(texts_logged_out, "%%s", readData("username"))

      removeData("username")
      removeData("apikey")

      activity.recreate()

      local anchor=activity.findViewById(android.R.id.content)
      Snackbar.make(anchor, texts_logged_out_processed, Snackbar.LENGTH_SHORT).show()

    end)
    .setNegativeButton(text_cancel, function()
      dialog.dismiss()
    end)
    .show()

   else
    local anchor=activity.findViewById(android.R.id.content)
    Snackbar.make(anchor, texts_not_logged, Snackbar.LENGTH_SHORT).show()

  end
end

local custom_url_layout = {
  LinearLayout,
  padding="16dp",
  orientation="vertical",
  {
    TextView,
    paddingStart="4dp",
    text=texts_function_needs_restart,
    id="textCustomUrl",
  },
  {
    TextInputLayout,
    layout_width="fill",
    paddingTop="16dp",
    hint=text_custom_url_example,
    id="inputCustomUrl",
    {
      TextInputEditText,
      layout_width="fill",
      background="#00ffffff",
      textSize="16sp",
      singleLine=true,
      id="editCustomUrl",
    },
  },
}

cardCustomUrl.onClick = function()
  dialog = MaterialAlertDialogBuilder(this)
  .setTitle(text_custom_url)
  .setView(loadlayout(custom_url_layout))
  .setPositiveButton(text_confirm, function()
    if #editCustomUrl.Text == 0 then
      local anchor=activity.findViewById(android.R.id.content)
      Snackbar.make(anchor, error_custom_url_blank, Snackbar.LENGTH_SHORT).show()

     elseif editCustomUrl.Text:find("%s") or editCustomUrl.Text:find("http") or editCustomUrl.Text:find("%/") then
      local anchor=activity.findViewById(android.R.id.content)
      Snackbar.make(anchor, error_custom_url_format, Snackbar.LENGTH_SHORT).show()

     else
      refreshLayout.refreshing = true

      Http.get("https://"..editCustomUrl.Text, nil, "utf-8", nil, function(code, content)
        if code == 200 then
          refreshLayout.refreshing = false

          saveData("custom_url", "1")
          saveData("site", editCustomUrl.Text)

          activity.recreate()

         else
          refreshLayout.refreshing = false

          local error_custom_url_processed = string.gsub(error_custom_url, "%%s", code)

          local anchor=activity.findViewById(android.R.id.content)
          Snackbar.make(anchor, error_custom_url_processed, Snackbar.LENGTH_SHORT).show()

        end
      end)
    end
  end)
  .setNegativeButton(text_cancel, function()
    dialog.dismiss()
  end)
  .setNeutralButton(text_delete, function()
    deleteDialog = MaterialAlertDialogBuilder(this)
    .setTitle(text_custom_url_delete)
    .setMessage(texts_custom_url_delete)
    .setPositiveButton(text_delete, function()
      removeData("custom_url")
      saveData("site", "e926.net")
      deleteDialog.dismiss()

      activity.recreate()
    end)
    .setNegativeButton(text_cancel, function()
      deleteDialog.dismiss()
    end)
    .show()

  end)
  .show()

  if readData("url") != nil then
    editCustomUrl.Text = readData("url")
  end

end