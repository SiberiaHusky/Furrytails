-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "search/layout"

local window = activity.getWindow()
window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
-- 设置布局
activity.setContentView(loadlayout("search/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}

--[[local searchTitleData = {
  "分数",
  "收藏数",
  "排序",
  "评级",
  "图集",
  "子资源",
  "父资源",
  "上传时间",
  "状态"
}

-- 创建适配器
adapterSearch = LuaCustRecyclerAdapter(AdapterCreator({

  -- 获取数据项数量
  getItemCount = function()
    return #searchTitleData
  end,

  -- 获取数据项视图类型
  getItemViewType = function(position)
    return 0
  end,

  -- 创建 ViewHolder
  onCreateViewHolder = function(parent, viewType)
    local views = {}

    -- 加载布局文件
    holder = LuaCustRecyclerHolder(loadlayout(import "search/items_layout", views))
    holder.view.setTag(views)
    return holder
  end,

  -- 绑定 ViewHolder
  onBindViewHolder = function(holder, position)
    local view = holder.view.getTag()

    view.titleMain.Text = searchTitleData[position + 1]

    local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
    alphaAnimation.setDuration(200)
    alphaAnimation.setInterpolator(DecelerateInterpolator())
    alphaAnimation.setRepeatCount(0.5)
    alphaAnimation.setRepeatMode(Animation.REVERSE)
    alphaAnimation.start()
  end
}))

recyclerSearch.setAdapter(adapterSearch) -- 设置适配器
recyclerSearch.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器
]]
cardSearch.onClick = function()
  if #editSearch.Text == 0 then
    activity.finish()

   else
    activity.newActivity("tags", {editSearch.Text})
  end
end

import "cjson"

editSearch.setOnFocusChangeListener{
  onFocusChange=function(v, hasFocus)
    if hasFocus then

      editSearch.addTextChangedListener{
        onTextChanged=function(s)

          if #editSearch.Text != 0 then
            Http.get("https://"..readData("site").."/tags.json?search[name_matches]="..editSearch.Text.."*", nil, "utf-8", nil, function(code, content)
              if code == 200 then
                local content = cjson.decode(content)

                tagSearchData = {}

                cardTagSearch.setVisibility(0)

                for i = 1, #content do
                  table.insert(tagSearchData, content[i])
                end
              end

              adapterEdit = LuaCustRecyclerAdapter(AdapterCreator({
                -- 获取数据项数量
                getItemCount = function()
                  return #tagSearchData
                end,

                -- 获取数据项视图类型
                getItemViewType = function(position)
                  return 0
                end,

                -- 创建 ViewHolder
                onCreateViewHolder = function(parent, viewType)
                  local views = {}

                  -- 加载布局文件
                  holder = LuaCustRecyclerHolder(loadlayout(import "search/list_layout", views))
                  holder.view.setTag(views)
                  return holder
                end,

                -- 绑定 ViewHolder
                onBindViewHolder = function(holder, position)
                  local view = holder.view.getTag()

                  view.textName.Text = tagSearchData[position + 1].name
                  view.textCount.Text = tostring(tointeger(tagSearchData[position + 1].post_count))

                  view.cardList.onClick = function()
                    editSearch.Text = tagSearchData[position + 1].name
                  end

                  local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
                  alphaAnimation.setDuration(200)
                  alphaAnimation.setInterpolator(DecelerateInterpolator())
                  alphaAnimation.setRepeatCount(0.5)
                  alphaAnimation.setRepeatMode(Animation.REVERSE)
                  alphaAnimation.start()
                end
              }))

              recyclerEdit.setAdapter(adapterEdit) -- 设置适配器
              recyclerEdit.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

            end)
          end

        end
      }

      linearlayout.onClick = function()
        editSearch.setFocusable(false)
        editSearch.setFocusableInTouchMode(true)

        cardTagSearch.setVisibility(8)
      end

     else


    end
  end
}