local packManager = this.getPackageManager()
local packInfo = packManager.getPackageInfo(this.getPackageName(),0)

local appName = packManager.getApplicationLabel(this.getPackageManager().getApplicationInfo(this.getPackageName(),0))
local appVer = packInfo.versionName
local appVerCode = packInfo.versionCode

import "android.os.SystemProperties"

debugInformation = "\n\n".."Details:\n"..appName.." ("..appVer.." / "..appVerCode..")\n"..os.date("%Y-%m-%d %T").." / "..System.currentTimeMillis().."\n"..Locale.getDefault().getLanguage().."\n\nPhone info:\n"..Build.BRAND.." "..Build.MODEL.." ("..Build.DEVICE..")\n"..SystemProperties.get("ro.product.cpu.abi").."\n"..SystemProperties.get("ro.product.cpu.abilist").."\nSDK "..Build.VERSION.SDK.." / Android "..Build.VERSION.RELEASE

function transparencyAnimation(id,time,a1,a2)
  tAni = ObjectAnimator.ofFloat(id, "alpha", {a1, a2})
  tAni.setDuration(time) -- 动画时间
  tAni.setInterpolator(DecelerateInterpolator()) -- 设置动画插值器，减速
  tAni.start() -- 开始动画
end

function dp2px(dpValue)
  local scale = activity.getResources().getDisplayMetrics().density;
  return dpValue * scale + 0.5
end

function statusBarHeight()
  resourceId = activity.getResources().getIdentifier("status_bar_height", "dimen", "android")
  return activity.getResources().getDimensionPixelSize(resourceId)
end

function isChinese()
  if Locale.getDefault().getLanguage():find("zh") then
    return true
  end

  return false
end

function getFileDrawable(file)
  fis = FileInputStream(activity.getLuaDir().."/res/"..file..".png")
  bitmap = BitmapFactory.decodeStream(fis)
  return BitmapDrawable(activity.getResources(), bitmap)
end

-- SharedPreferences
function saveData(name, str)
  -- 获取 SharedPreferences 文件
  sp = activity.getSharedPreferences("furski", Context.MODE_PRIVATE)
  -- 设置编辑
  sped = sp.edit()
  -- 设置键值对
  sped.putString(name, str)
  -- 提交保存数据
  sped.commit()
end

function readData(name)
  --获取 SharedPreferences 文件
  sp = activity.getSharedPreferences("furski", Context.MODE_PRIVATE)
  --打印对应的值
  return sp.getString(name, nil)
end

function removeData(name)
  --获取 SharedPreferences 文件
  sp = activity.getSharedPreferences("furski", Context.MODE_PRIVATE)
  -- 设置编辑
  sped = sp.edit()
  -- 设置移除
  sped.remove(name)
  -- 提交改变
  sped.apply()
end

function isLogged()
  if readData("username") != nil and readData("apikey") != nil then
    return true
   else
    return false
  end
end

function openInBrowser(url)
  local viewIntent = Intent("android.intent.action.VIEW", Uri.parse(url))
  activity.startActivity(viewIntent)
end

function hideProcess(boolean)
  local activityManager = activity.getSystemService(Context.ACTIVITY_SERVICE)
  activityManager.appTasks[0].setExcludeFromRecents(boolean)
end

-- biometrics
function isBiometricsSupported()
  if Build.VERSION.SDK_INT < Build.VERSION_CODES.P then
    biometrics_unsupport_reason = error_biometrics_system_version
    return false

   elseif (activity.checkSelfPermission(Manifest.permission.USE_BIOMETRIC) ~= PackageManager.PERMISSION_GRANTED) then
    biometrics_unsupport_reason = error_biometrics_permission
    return false

   elseif not fingerprintManager.isHardwareDetected() then
    biometrics_unsupport_reason = error_biometrics_hardware
    return false

   elseif not keyManager.isKeyguardSecure() then
   biometrics_unsupport_reason = error_keyguard_secure
    return false

   elseif not fingerprintManager.hasEnrolledFingerprints() then
   biometrics_unsupport_reason = error_biometrics_fingerprint_not_enroll
    return false

  end

  return true
end

fingerprintManager = activity.getSystemService(Context.FINGERPRINT_SERVICE);
keyManager = activity.getSystemService(Context.KEYGUARD_SERVICE);
