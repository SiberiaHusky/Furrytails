-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()
secondary = themeUtil.getColorSecondary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "settings/layout"

-- 设置布局
activity.setContentView(loadlayout("settings/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
local window = activity.getWindow()
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

local packManager = this.getPackageManager()
local packInfo = packManager.getPackageInfo(this.getPackageName(),0)

local appName = packManager.getApplicationLabel(this.getPackageManager().getApplicationInfo(this.getPackageName(),0))
local appVer = packInfo.versionName
local appVerCode = packInfo.versionCode

local mainTitleData = {
  --text_general_settings,
  text_customization,
  text_privacy,
  text_about
}

local generalTitleData = {
  text_storage_and_download,
  text_block_list
}

local aboutTitleData = {
  text_official_website,
  text_author
}

local updatesTitleData = {}

local customizationTitleData = {
  text_account,
}

local privacyTitleData = {
  text_hide_process,
  text_lock
}

import "cjson"

-- 创建适配器
adapterMain = LuaCustRecyclerAdapter(AdapterCreator({

  -- 获取数据项数量
  getItemCount = function()
    return #mainTitleData
  end,

  -- 获取数据项视图类型
  getItemViewType = function(position)
    return 0
  end,

  -- 创建 ViewHolder
  onCreateViewHolder = function(parent, viewType)
    local views = {}

    -- 加载布局文件
    holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_layout", views))
    holder.view.setTag(views)
    return holder
  end,

  -- 绑定 ViewHolder
  onBindViewHolder = function(holder, position)
    local view = holder.view.getTag()

    view.titleMain.Text = mainTitleData[position + 1]

    if mainTitleData[position + 1] == text_general_settings then -- 如果是“通用设置”则
      -- 创建适配器
      adapterGeneral = LuaCustRecyclerAdapter(AdapterCreator({

        -- 获取数据项数量
        getItemCount = function()
          return #generalTitleData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_card", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.titleSub.Text = generalTitleData[position + 1]

          view.cardItems.onClick = function()
          end
        end
      }))

      local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
      alphaAnimation.setDuration(200)
      alphaAnimation.setInterpolator(DecelerateInterpolator())
      alphaAnimation.setRepeatCount(0.5)
      alphaAnimation.setRepeatMode(Animation.REVERSE)
      alphaAnimation.start()

      view.recyclerItems.setAdapter(adapterGeneral) -- 设置适配器
      view.recyclerItems.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

     elseif mainTitleData[position + 1] == text_about then -- 如果是“关于”则
      -- 创建适配器
      adapterAbout = LuaCustRecyclerAdapter(AdapterCreator({

        -- 获取数据项数量
        getItemCount = function()
          return #aboutTitleData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_card", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.titleSub.Text = aboutTitleData[position + 1]

          view.cardItems.onClick = function()
            if aboutTitleData[position + 1] == text_official_website then -- 官方网站
              openInBrowser("https://pj.hooskai.top/furski/")

             elseif aboutTitleData[position + 1] == text_author then -- 作者
              openInBrowser("https://intl.hooskai.top/")
            end
          end
        end
      }))

      local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
      alphaAnimation.setDuration(200)
      alphaAnimation.setInterpolator(DecelerateInterpolator())
      alphaAnimation.setRepeatCount(0.5)
      alphaAnimation.setRepeatMode(Animation.REVERSE)
      alphaAnimation.start()

      view.recyclerItems.setAdapter(adapterAbout) -- 设置适配器
      view.recyclerItems.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

     elseif mainTitleData[position + 1] == text_privacy then -- 如果是“隐私”则
      -- 创建适配器
      adapterPrivacy = LuaCustRecyclerAdapter(AdapterCreator({

        -- 获取数据项数量
        getItemCount = function()
          return #privacyTitleData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_card_switch", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.titleSub.Text = privacyTitleData[position + 1]

          if privacyTitleData[position + 1] == text_lock then -- 如果是“锁定”则隐藏 switch
            view.switchItems.setVisibility(8)

           elseif privacyTitleData[position + 1] == text_hide_process then
            if readData("hide_process") != nil then
              view.switchItems.setChecked(true)
            end

          end

          view.switchItems.onClick = function()
            if view.switchItems.isChecked() then
              if privacyTitleData[position + 1] == text_hide_process then
                local texts_needs_restart_app_processed = texts_needs_restart_app:gsub("%%s", privacyTitleData[position + 1])

                dialog = MaterialAlertDialogBuilder(this)
                .setTitle(privacyTitleData[position + 1])
                .setMessage(texts_needs_restart_app_processed)
                .setPositiveButton(text_confirm, function()
                  hideProcess(true)
                  saveData("hide_process", "1")

                  view.switchItems.setChecked(true)
                end)

                .setNegativeButton(text_cancel, function()
                  dialog.dismiss()

                end)
              end

             else
              if privacyTitleData[position + 1] == text_hide_process then
                hideProcess(false)
                removeData("hide_process")

              end

            end
          end

          view.cardItems.onClick = function()
            if privacyTitleData[position + 1] == text_lock then
              activity.newActivity("lock")

             elseif privacyTitleData[position + 1] == text_hide_process then
              dialog = MaterialAlertDialogBuilder(this)
              .setTitle(text_hide_process)
              .setMessage(texts_hide_process)
              .setPositiveButton(text_confirm, function()
                dialog.dismiss()
              end)
              .show()

            end
          end
        end
      }))

      local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
      alphaAnimation.setDuration(200)
      alphaAnimation.setInterpolator(DecelerateInterpolator())
      alphaAnimation.setRepeatCount(0.5)
      alphaAnimation.setRepeatMode(Animation.REVERSE)
      alphaAnimation.start()

      view.recyclerItems.setAdapter(adapterPrivacy) -- 设置适配器
      view.recyclerItems.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

     elseif mainTitleData[position + 1] == text_update then -- 如果是“更新”则
      -- 创建适配器
      adapterUpdates = LuaCustRecyclerAdapter(AdapterCreator({

        -- 获取数据项数量
        getItemCount = function()
          return #updatesTitleData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_card", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.titleSub.Text = updatesTitleData[position + 1]

          view.cardItems.onClick = function()
            if updatesTitleData[position + 1] == text_update_history then -- 更新历史
              if isChinese() then
                updateHistory = updateData.CHN.UpdateStory
               else
                updateHistory = updateData.ENG.UpdateStory
              end

              dialog = MaterialAlertDialogBuilder(this)
              .setTitle(updatesTitleData[position + 1])
              .setMessage(updateHistory)
              .setPositiveButton(text_confirm,{onClick = function(v)
                  dialog.dismiss()
              end})
              .show()

             else -- 版本
              if tointeger(appVerCode) > tointeger(updateData.VersionCode) then
                dialog = MaterialAlertDialogBuilder(this)
                .setTitle(text_update)
                .setMessage(appVer.." ("..appVerCode..") > "..updateData.VersionName.." ("..tointeger(updateData.VersionCode)..")".."\n"..texts_update_version_wrong)
                .setPositiveButton(text_download,{onClick = function(v)
                    import "android.content.Intent"
                    import "android.net.Uri"
                    viewIntent = Intent("android.intent.action.VIEW",Uri.parse(updateData.UpdateUrl))
                    activity.startActivity(viewIntent)

                    dialog.dismiss()
                end})
                .setNegativeButton(text_cancel,{onClick = function()
                    dialog.dismiss()
                end})
                .show()

               elseif tointeger(appVerCode) < tonumber(updateData.VersionCode) then
                dialog = MaterialAlertDialogBuilder(this)
                .setTitle(text_update)
                .setMessage(appVer.." ("..appVerCode..") < "..updateData.VersionName.." ("..tointeger(updateData.VersionCode)..")".."\n"..texts_update_version_new)
                .setPositiveButton(text_download,{onClick = function(v)
                    import "android.content.Intent"
                    import "android.net.Uri"
                    viewIntent = Intent("android.intent.action.VIEW",Uri.parse(updateData.UpdateUrl))
                    activity.startActivity(viewIntent)

                    dialog.dismiss()
                end})
                .setNegativeButton(text_cancel,{onClick = function()
                    dialog.dismiss()
                end})
                .show()

               else
                dialog = MaterialAlertDialogBuilder(this)
                .setTitle(text_update)
                .setMessage(texts_update_version_latest)
                .setPositiveButton(text_confirm,{onClick = function(v)
                    dialog.dismiss()
                end})
                .show()

              end

            end
          end
        end
      }))

      local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
      alphaAnimation.setDuration(200)
      alphaAnimation.setInterpolator(DecelerateInterpolator())
      alphaAnimation.setRepeatCount(0.5)
      alphaAnimation.setRepeatMode(Animation.REVERSE)
      alphaAnimation.start()

      view.recyclerItems.setAdapter(adapterUpdates) -- 设置适配器
      view.recyclerItems.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

     elseif mainTitleData[position + 1] == text_customization then -- 如果是“客制化”则
      -- 创建适配器
      adapterCustomization = LuaCustRecyclerAdapter(AdapterCreator({

        -- 获取数据项数量
        getItemCount = function()
          return #customizationTitleData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "settings/items_card", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.titleSub.Text = customizationTitleData[position + 1]

          view.cardItems.onClick = function()
            if customizationTitleData[position + 1] == text_account then
              activity.newActivity("account")

            end
          end
        end
      }))

      local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
      alphaAnimation.setDuration(200)
      alphaAnimation.setInterpolator(DecelerateInterpolator())
      alphaAnimation.setRepeatCount(0.5)
      alphaAnimation.setRepeatMode(Animation.REVERSE)
      alphaAnimation.start()

      view.recyclerItems.setAdapter(adapterCustomization) -- 设置适配器
      view.recyclerItems.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器

    end

  end
}))

local alphaAnimation = ObjectAnimator.ofFloat(recyclerMain, "alpha", {0, 1})
alphaAnimation.setDuration(200)
alphaAnimation.setInterpolator(DecelerateInterpolator())
alphaAnimation.setRepeatCount(0.5)
alphaAnimation.setRepeatMode(Animation.REVERSE)
alphaAnimation.start()

Http.get("https://pj.hooskai.top/furski/update.json",function(code,content)
  if code == 200 then
    local content = cjson.decode(content)

    table.insert(mainTitleData, 3, text_update)
    table.insert(updatesTitleData, text_update_history)

    if tointeger(appVerCode) > tointeger(content.VersionCode) then -- 应用版本号大于服务器版本号则
      table.insert(updatesTitleData,"V"..appVer.." ("..appVerCode..") !")

     elseif tointeger(appVerCode) < tonumber(content.VersionCode) then -- 应用版本号小于服务器版本号则
      table.insert(updatesTitleData,"V"..appVer.." ("..appVerCode..") *")

     else
      table.insert(updatesTitleData,"V"..appVer.." ("..appVerCode..")")
    end

    updateData = content

  end

  recyclerMain.setAdapter(adapterMain) -- 设置适配器
  recyclerMain.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器
end)


toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}