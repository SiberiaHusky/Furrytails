require "import"
import "android.widget.*"
import "android.view.*"

import "requireImports"
import "functions"

local page = ...

biometricPrompt = BiometricPrompt.Builder(this)
.setTitle("Biometrics Enabled")
.setDescription("请通过验证")
.setNegativeButton(text_cancel, activity.getMainExecutor(),
function()
end)
.build()

cancellationSignal = CancellationSignal()

myAuthenticationCallback = BiometricPrompt.AuthenticationCallback({
  onAuthenticationError = function(code, msg)
    --一般onAuthenticationFailed方法调用五次后会调用此方法，显示稍后重试。
    print(code, msg)
  end,
  onAuthenticationHelp = function(code, msg)
    print(code, msg)
  end,
  onAuthenticationSucceeded = function(result)
    activity.finish()
    activity.newActivity(page, {true})

    if cancellationSignal ~= nil then
      cancellationSignal.cancel()
      cancellationSignal = nil
    end
  end,
  onAuthenticationFailed = function()
    activity.finish()
  end
})

if isBiometricsSupported() then
  biometricPrompt.authenticate(cancellationSignal, activity.getMainExecutor(), myAuthenticationCallback);
end