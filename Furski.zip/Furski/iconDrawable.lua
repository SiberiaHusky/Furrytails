require "import"
import "android.util.TypedValue"
import "android.graphics.PorterDuff"
import "android.graphics.PorterDuffColorFilter"
import "android.graphics.drawable.BitmapDrawable"
import "android.graphics.Bitmap"
import "android.graphics.Matrix"

local IMAGE_DIR_PATH = activity.LuaDir.."/res/"

return function(image, viewSizeDp)
  local bitmap = LuaBitmap
    .getLocalBitmap(IMAGE_DIR_PATH..image)
  local size = bitmap.width
  local viewSizeDp = viewSizeDp or 56
  local r = activity.resources.displayMetrics
  local scale = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP, viewSizeDp, r) / size
  local matrix = Matrix()
  matrix.postScale(scale, scale)  

  local bitmap = Bitmap.createBitmap(
    bitmap, 0, 0, size, size, matrix, true)
  return BitmapDrawable(bitmap)
end
