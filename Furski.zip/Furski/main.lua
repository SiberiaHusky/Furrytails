-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "layout"

local window = activity.getWindow()
window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
-- 设置布局
activity.setContentView(loadlayout(layout))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

refreshLayout.setColorSchemeColors{primaryc}
refreshLayout.setProgressBackgroundColorSchemeColor(backgroundc)

local pageSerial = 1
local mainData = {}
local infoIconData = {
  "/thumb_up_black_24dp",
  "/outline_favorite_black_24dp",
  "/comments_black_24dp",
}

refreshLayout.refreshing = true

import "cjson"

if readData("site") == nil then
  saveData("site", "e926.net")
end

function initData(url)
  if toolbar.getTitle() == text_error then
    activity.recreate()
  end

  refreshLayout.setOnRefreshListener{
    onRefresh=function()
      mainData = {}

      initData(url)
    end
  }

  Http.get(url, nil, "utf-8", nil, function(code, content)
    if code == 200 then
      refreshLayout.refreshing = false

      local content = cjson.decode(content)

      for i=1, #content.posts do
        mainData[i] = {
          --image
          image = content.posts[i].sample.url,
          --id
          id = content.posts[i].id,
          --info
          info = {
            Math.round(content.posts[i].score.total),
            Math.round(content.posts[i].fav_count),
            Math.round(content.posts[i].comment_count),
            string.upper(content.posts[i].rating),
          },
        }
      end

      -- 创建适配器
      adapterMain = LuaCustRecyclerAdapter(AdapterCreator({
        -- 获取数据项数量
        getItemCount = function()
          return #mainData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "items_layout", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          if tostring(mainData[position +1].image) != "userdata: 0x0" then
            Glide.with(activity).load(mainData[position + 1].image).into(view.imageMain)
          end

          view.cardMain.onClick=function()
            activity.newActivity("viewer", {mainData[position + 1].id})
          end

          adapterInfo = LuaCustRecyclerAdapter(AdapterCreator({
            -- 获取数据项数量
            getItemCount = function()
              return #mainData[position + 1].info
            end,

            -- 获取数据项视图类型
            getItemViewType = function(position)
              return 0
            end,

            -- 创建 ViewHolder
            onCreateViewHolder = function(parent, viewType)
              local views = {}

              -- 加载布局文件
              holder = LuaCustRecyclerHolder(loadlayout(import "info_layout", views))
              holder.view.setTag(views)
              return holder
            end,

            -- 绑定 ViewHolder
            onBindViewHolder = function(holder, pos)
              local view = holder.view.getTag()

              -- 设置数据到视图中
              -- 设置文本
              view.textInfo.Text = tostring(mainData[position + 1].info[pos + 1])

              -- 设置图标
              if pos != 3 then
                Glide.with(activity).load(activity.getLuaDir().."/res"..infoIconData[pos + 1]..".png").into(view.imageInfo)--设置图标

               else
                view.imageInfo.setVisibility(View.GONE)
              end

            end
          }))

          view.recyclerInfo.setAdapter(adapterInfo)
          view.recyclerInfo.setLayoutManager(StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL)) -- 设置布局管理器

          local alphaAnimation = ObjectAnimator.ofFloat(view.layoutMain, "alpha", {0, 1})
          alphaAnimation.setDuration(200)
          alphaAnimation.setInterpolator(DecelerateInterpolator())
          alphaAnimation.setRepeatCount(0.5)
          alphaAnimation.setRepeatMode(Animation.REVERSE)
          alphaAnimation.start()

          if recyclerMain.adapter.getItemCount() == position +1 then
            pageSerial = pageSerial + 1
            newDataAdd(url.."&page="..pageSerial, position + 1)
          end

        end
      }))

      recyclerMain.setAdapter(adapterMain) -- 设置适配器
      recyclerMain.setLayoutManager(StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL)) -- 设置布局管理器
      recyclerMain.layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE)

     else
      refreshLayout.refreshing = false

      scrollView.removeAllViews()
      scrollView.addView(loadlayout(import "error/layout"))

      toolbar.setTitle(text_error)
      textCode.Text = tostring(code)

      if code == 404 then
        textError.Text = error_404

       elseif code == 401 then
        if readData("custom_url") == nil then
          local error_auth_processed = string.gsub(error_auth, "%%s", readData("site"))
          textError.Text = error_auth_processed

         else
          local error_auth_custom_url_processed = string.gsub(error_auth_custom_url, "%%s", readData("site"))
          textError.Text = error_auth_custom_url_processed

        end

       elseif code == -1 then
        if readData("site") == "e621.net" then
          textError.Text = error_e621

         else
          textError.Text = error_no_network

        end

       else
        toolbar.setTitle(text_error)
        textCode.Text = tostring(code)
        textError.Text = texts_error..debugInformation

      end

    end
  end)

  -- 瀑布流数据添加
  function newDataAdd(url, index)
    refreshLayout.refreshing = true

    Http.get(url, nil, "utf-8", nil, function(code, content)
      if code == 200 then
        refreshLayout.refreshing = false

        local content = cjson.decode(content)

        for i=1,#content.posts do
          table.insert(mainData, index + i, {
            --image
            image = content.posts[i].sample.url,
            --id
            id = content.posts[i].id,
            --info
            info = {
              Math.round(content.posts[i].score.total),
              Math.round(content.posts[i].fav_count),
              Math.round(content.posts[i].comment_count),
              string.upper(content.posts[i].rating),
            },
          })
        end

        -- 使用 notifyItemRangeChanged 避免顶部出现空白
        adapterMain.notifyItemRangeChanged(index, 10)
      end
    end)
  end

end

if isLogged() then
  url = "https://"..readData("site").."/posts.json?limit=10&login="..readData("username").."&api_key="..readData("apikey")
  initData(url.."&page="..pageSerial)

 else
  url = "https://"..readData("site").."/posts.json?limit=10"
  initData(url.."&page="..pageSerial)
end

-- Toolbar 菜单
local navigationMenu = toolbar.menu

import "iconDrawable"

navigationMenu.add(0,0,0,text_search).setIcon(iconDrawable("search_black_24dp.png")).setShowAsAction(2)

local appName = this.getPackageManager().getApplicationLabel(this.getPackageManager().getApplicationInfo(this.getPackageName(),0))

toolbar.setOnMenuItemClickListener(OnMenuItemClickListener{
  onMenuItemClick=function(item)
    if tostring(item) == text_search then
      activity.newActivity("search")
    end
  end
})

toolbar.setNavigationOnClickListener{
  onClick=function()
    drawerLayout.openDrawer(Gravity.START)
  end
}

-- NavigationView
navview.addHeaderView(loadlayout(import "nav_header_layout"))
-- 设置侧滑栏数据
local navData = {
  {text = text_home, icon = "home_black_24dp"},
  {text = text_hot, icon = "hot_black_24dp"},
  --[[{text = text_gallery, icon = "gallery_black_24dp"},
  {text = text_forum, icon = "forum_black_24dp"},]]
  {text = text_account, icon = "account_black_24dp"},
  {text = text_settings, icon = "setting_black_24dp"},
}

if isLogged() then
  table.insert(navData, 3, {text = text_favorite, icon = "favorite_black_24dp"})
end

-- 循环设置侧滑栏
for i = 1, #navData do

  -- 如果是主页和热门则
  if navData[i].text == text_home or navData[i].text == text_hot or navData[i].text == text_favorite then
    -- 添加可选择的侧滑栏项目和文字
    navview.menu.add(0,i,i,navData[i].text).setCheckable(true)

   else -- 否则
    -- 添加不可选择的侧滑栏项目和文字
    navview.menu.add(0,i,i,navData[i].text).setCheckable(false)
  end

  -- 设置侧滑栏图标
  navview.menu.findItem(i).setIcon(getFileDrawable(navData[i].icon))
end

navview.setCheckedItem(navview.menu.findItem(1))

-- NavigationView 监听
navview.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener{
  onNavigationItemSelected = function(item)
    navview.setCheckedItem(item)

    -- 关闭侧滑栏
    drawerLayout.closeDrawer(Gravity.START)

    -- 定义item
    local item = tostring(item)

    -- 判断当前项目
    if item == text_home then -- 主页
      -- 加载主页
      refreshLayout.refreshing = true

      pageSerial = 1

      initData(url.."&page="..pageSerial)
      -- 设置 title 文字
      toolbar.setTitle("Furski")

     elseif item == text_hot then -- 热门
      -- 加载主页
      refreshLayout.refreshing = true

      pageSerial = 1

      initData(url.."&tags=order:rank&page="..pageSerial)
      -- 设置 title 文字
      toolbar.setTitle(text_hot)

     elseif item == text_favorite then -- 收藏
      -- 加载收藏
      refreshLayout.refreshing = true

      pageSerial = 1

      initData(url.."&tags=fav:"..readData("username").."&page="..pageSerial)
      -- 设置 title 文字
      toolbar.setTitle(text_favorite)

     elseif item == text_pools then -- 图集
      -- 进入图集子页面

     elseif item == text_forum then -- 论坛
      -- 进入论坛子页面

     elseif item == text_account then -- 账户
      -- 进入账户子界面
      activity.newActivity("account")

     elseif item == text_settings then -- 设置
      -- 进入设置子页面
      activity.newActivity("settings")
    end

    return true
  end
})

navview.drawerLayoutCornerSize=0
navview.background=navview.background.setShapeAppearanceModel(ShapeAppearanceModel.builder().setTopRightCornerSize(dp2px(20)).setBottomRightCornerSize(dp2px(20)).build())

local isBiometricsPassed = ...

if readData("biometrics") != nil and isBiometricsPassed == nil then
  activity.finish()
  activity.newActivity("biometrics", {"main"})
end