-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()
secondary = themeUtil.getColorSecondary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "viewer/layout"

-- 设置布局
activity.setContentView(loadlayout("viewer/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
local window = activity.getWindow()
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

refreshLayout.setColorSchemeColors{primaryc}
refreshLayout.setProgressBackgroundColorSchemeColor(backgroundc)

refreshLayout.refreshing = true

local intent = activity.getIntent()
local id = tointeger(...)
--id = 4444322

if isLogged() then
  url = "https://"..readData("site").."/posts/"..id..".json?login="..readData("username").."&api_key="..readData("apikey")
 else
  url = "https://"..readData("site").."/posts/"..id..".json"
end

toolbar.setTitle("#"..id)

import "cjson"

local statusBarData = {
  {
    icon = activity.getLuaDir().."/res/download_black_24dp.png",
    text = text_download,
  },
  {
    icon = activity.getLuaDir().."/res/fullscreen_black_24dp.png",
    text = text_definition_sample,
  },
}

local childrenData = {}

local tagsData = {}
local tagsTitleData = {}
local tagsTitleTextData = {
  text_artist,
  text_character,
  text_copyright,
  text_species,
  text_general,
  text_meta,
  text_lore,
  text_invalid
}

function initData(url)
  refreshLayout.setOnRefreshListener{
    onRefresh=function()
      statusBarData = {
        {
          icon = activity.getLuaDir().."/res/download_black_24dp.png",
          text = text_download,
        },
        {
          icon = activity.getLuaDir().."/res/fullscreen_black_24dp.png",
          text = text_definition_sample,
        },
      }
      childrenData = {}
      tagsData = {}
      tagsTitleData = {}

      initData(url)
    end
  }

  Http.get(url, "Furski/ 0.2.1 (by SiberiaHusky on e926)", "utf-8", nil, function(code, content)
    if code == 200 then
      refreshLayout.refreshing = false

      local content = cjson.decode(content)

      if tostring(content.post.file.url) != "userdata: 0x0" then
        Glide.with(activity).load(content.post.sample.url).into(imageMain)
      end

      if content.post.is_favorited then
        table.insert(statusBarData, {
          icon = activity.getLuaDir().."/res/favorite_black_24dp.png",
          text = text_favorited,
        })

       else
        table.insert(statusBarData, {
          icon = activity.getLuaDir().."/res/outline_favorite_black_24dp.png",
          text = text_favorite,
        })
      end

      -- 创建适配器
      adapterStatusBar = LuaCustRecyclerAdapter(AdapterCreator({
        -- 获取数据项数量
        getItemCount = function()
          return #statusBarData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "viewer/status_bar_layout", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          Glide.with(this).load(statusBarData[position + 1].icon).into(view.imageStatusBar)
          view.textStatusBar.Text = statusBarData[position + 1].text

          view.cardStatusBar.onClick = function()
            if position == 0 then -- 如果是下载则
              Http.download(content.post.file.url, "/sdcard/Download/Furski/"..id.."."..content.post.file.ext, nil, nil, function(code, ct)
                if code == 200 then
                  print("File is being downloaded...\n(Path: /sdcard/Download/Furski/"..id.."."..content.post.file.ext)
                end
              end)

             elseif position == 1 then -- 如果是清晰度则
              local dialogData = {
                text_definition_sample,
                text_definition_original,
              }

              if view.textStatusBar.Text == text_definition_sample then
                imageDialogSerial = 0

               else
                imageDialogSerial = 1
              end

              dialog = MaterialAlertDialogBuilder(this)
              .setTitle(text_definition)
              .setSingleChoiceItems(dialogData, imageDialogSerial, {onClick = function(l,v)
                  if v == 0 then -- sample
                    view.textStatusBar.Text = text_definition_sample
                    Glide.with(activity).load(content.post.sample.url).into(imageMain)

                   else -- original
                    view.textStatusBar.Text = text_definition_original
                    Glide.with(activity).load(content.post.file.url).into(imageMain)

                  end
              end})
              .show()

             elseif position == 2 then -- 如果是收藏则
              if isLogged() then
                refreshLayout.refreshing = true

                if content.post.is_favorited then
                  refreshLayout.refreshing = false

                  Http.delete("https://"..readData("site").."/favorites/"..id..".json?login="..readData("username").."&api_key="..readData("apikey"), nil, "utf-8", nil, function(code, content)
                    if code == 200 or code == 204 then
                      refreshLayout.refreshing = false
                      activity.recreate()

                     else
                      refreshLayout.refreshing = false

                      local error_favorites_delete_processed = string.gsub(error_favorites_delete, "%%s", code)

                      local anchor=activity.findViewById(android.R.id.content)
                      Snackbar.make(anchor, error_favorites_delete_processed, Snackbar.LENGTH_SHORT).show()

                    end
                  end)

                 else
                  local postData = {
                    ["post_id"] = tostring(id),
                  }

                  Http.post("https://"..readData("site").."/favorites.json?login="..readData("username").."&api_key="..readData("apikey"), postData, nil, "utf-8", nil, function(code, content)
                    if code == 200 or code == 201 then
                      refreshLayout.refreshing = false
                      activity.recreate()

                     else
                      refreshLayout.refreshing = false

                      local error_favorites_processed = string.gsub(error_favorites, "%%s", code)

                      local anchor=activity.findViewById(android.R.id.content)
                      Snackbar.make(anchor, error_favorites_processed, Snackbar.LENGTH_SHORT).show()

                    end
                  end)

                end

               else
                local anchor=activity.findViewById(android.R.id.content)
                Snackbar.make(anchor, texts_not_logged, Snackbar.LENGTH_SHORT).show()

              end

            end

          end
        end
      }))

      recyclerStatusBar.setAdapter(adapterStatusBar) -- 设置适配器
      recyclerStatusBar.setLayoutManager(GridLayoutManager(activity, #statusBarData)) -- 设置布局管理器

      -- 关系
      -- 父
      if type(content.post.relationships.parent_id) != "number" then
        cardParent.setVisibility(8)

       else
        cardParent.setVisibility(0)
        textParentId.Text = "#"..tointeger(content.post.relationships.parent_id)
        textParentId.setTextSize(16)
      end

      cardParent.onClick = function()
        activity.newActivity("viewer", {tointeger(content.post.relationships.parent_id)})
      end

      for i = 1, #content.post.relationships.children do
        table.insert(childrenData, content.post.relationships.children[i])
      end

      -- 子
      if content.post.relationships.has_children != true then
        cardChildren.setVisibility(8)

       else
        cardChildren.setVisibility(0)

        cardChildren.onClick = function()
          activity.newActivity("tags", {"parent:"..id})
        end

        if groupChildren.getChildCount() >= #childrenData then
          groupChildren.removeAllViews()

          for i = 1, #childrenData do
            groupChildren.addView(loadlayout("viewer/tag_layout"))

            tagCard.setCardBackgroundColor(surfaceVar)
            tagCard.setStrokeColor(surfaceVar)
            tagName.Text = "#"..tointeger(childrenData[i])

            tagCard.onClick=function()
              activity.newActivity("viewer", {tointeger(content.post.relationships.children[i])})
            end
          end

         else
          for i = 1, #childrenData do
            groupChildren.addView(loadlayout("viewer/tag_layout"))

            tagCard.setCardBackgroundColor(surfaceVar)
            tagCard.setStrokeColor(surfaceVar)
            tagName.Text = "#"..tointeger(childrenData[i])

            tagCard.onClick=function()
              activity.newActivity("viewer", {tointeger(content.post.relationships.children[i])})
            end
          end

        end
      end

      -- 上传者
      textUploader.Text = tostring(tointeger(content.post.uploader_id))
      -- 投票分数
      textVoteUpScore.Text = tostring(tointeger(content.post.score.up))
      textVoteDownScore.Text = tostring(tointeger(content.post.score.down))

      cardVoteUp.onClick = function()
        if isLogged() then
          local voteData = {
            ["score"] = "1",
          }

          Http.post("https://"..readData("site").."/posts/"..id.."/votes.json?login="..readData("username").."&api_key="..readData("apikey"), voteData, nil, "utf-8", nil, function(code, content)
            if code == 200 then
              local content = cjson.decode(content)
              textVoteUpScore.Text = tostring(tointeger(content.up))
              textVoteDownScore.Text = tostring(tointeger(content.down))

              if tointeger(content.our_score) > 0 then
                Glide.with(activity).load(activity.getLuaDir().."/res/thumb_up_black_24dp.png").into(imageVoteUp)
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_down_black_24dp.png").into(imageVoteDown)

               else
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_up_black_24dp.png").into(imageVoteUp)
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_down_black_24dp.png").into(imageVoteDown)

              end

             else
              local error_vote_processed = string.gsub(error_vote, "%%s", code)

              local anchor=activity.findViewById(android.R.id.content)
              Snackbar.make(anchor, error_vote_processed, Snackbar.LENGTH_SHORT).show()
            end
          end)

         else
          local anchor=activity.findViewById(android.R.id.content)
          Snackbar.make(anchor, texts_not_logged, Snackbar.LENGTH_SHORT).show()

        end
      end

      cardVoteDown.onClick = function()
        if isLogged() then
          local voteData = {
            ["score"] = "-1",
          }

          Http.post("https://"..readData("site").."/posts/"..id.."/votes.json?login="..readData("username").."&api_key="..readData("apikey"), voteData, nil, "utf-8", nil, function(code, content)
            if code == 200 then
              local content = cjson.decode(content)
              textVoteUpScore.Text = tostring(tointeger(content.up))
              textVoteDownScore.Text = tostring(tointeger(content.down))

              if tointeger(content.our_score) < 0 then
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_up_black_24dp.png").into(imageVoteUp)
                Glide.with(activity).load(activity.getLuaDir().."/res/thumb_down_black_24dp.png").into(imageVoteDown)

               else
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_up_black_24dp.png").into(imageVoteUp)
                Glide.with(activity).load(activity.getLuaDir().."/res/outline_thumb_down_black_24dp.png").into(imageVoteDown)

              end

             else
              local error_vote_processed = string.gsub(error_vote, "%%s", code)

              local anchor=activity.findViewById(android.R.id.content)
              Snackbar.make(anchor, error_vote_processed, Snackbar.LENGTH_SHORT).show()
            end
          end)

         else
          local anchor=activity.findViewById(android.R.id.content)
          Snackbar.make(anchor, texts_not_logged, Snackbar.LENGTH_SHORT).show()

        end
      end

      -- 标签标题
      tagsTitleLowercaseData = {
        content.post.tags.artist,
        content.post.tags.character,
        content.post.tags.copyright,
        content.post.tags.species,
        content.post.tags.general,
        content.post.tags.meta,
        content.post.tags.lore,
        content.post.tags.invalid,
      }

      if content.post.tags.director != nil then
        tagsTitleLowercaseData = {
          content.post.tags.director,
          content.post.tags.character,
          content.post.tags.species,
          content.post.tags.general,
          content.post.tags.meta,
          content.post.tags.invalid,
        }

        tagsTitleTextData = {
          text_director,
          text_character,
          text_species,
          text_general,
          text_meta,
          text_invalid
        }

      end

      for i = 1, #tagsTitleLowercaseData do
        if #tagsTitleLowercaseData[i] != 0 then
          table.insert(tagsData, tagsTitleLowercaseData[i])
          table.insert(tagsTitleData, tagsTitleTextData[i])
        end
      end

      -- 标签
      -- 创建适配器
      adapterTags = LuaCustRecyclerAdapter(AdapterCreator({
        -- 获取数据项数量
        getItemCount = function()
          return #tagsData
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "viewer/tags_layout", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()

          view.tagsCard.setCardBackgroundColor(primaryc)
          view.tagsCard.setStrokeColor(primaryc)
          view.tagsName.setText(tagsTitleData[position + 1])
          view.tagsName.setTextColor(surfaceColor)

          for i = 1, #tagsData[position + 1] do
            view.tagsGroup.addView(loadlayout(import "viewer/tag_layout"))
            tagCard.setCardBackgroundColor(surfaceVar)
            tagCard.setStrokeColor(surfaceVar)
            tagName.setText(tagsData[position + 1][i])

            tagCard.onClick = function()
              activity.newActivity("tags", {tagsData[position + 1][i]})
            end

          end

        end
      }))

      recyclerTags.setAdapter(adapterTags) -- 设置适配器
      recyclerTags.setLayoutManager(GridLayoutManager(activity, 1)) -- 设置布局管理器

      -- tointeger(content.post.comment_count)
      --评论区
      --[[ 创建适配器
      adapterComments = LuaCustRecyclerAdapter(AdapterCreator({
        -- 获取数据项数量
        getItemCount = function()
          return 0
        end,

        -- 获取数据项视图类型
        getItemViewType = function(position)
          return 0
        end,

        -- 创建 ViewHolder
        onCreateViewHolder = function(parent, viewType)
          local views = {}

          -- 加载布局文件
          holder = LuaCustRecyclerHolder(loadlayout(import "viewer/status_bar_layout", views))
          holder.view.setTag(views)
          return holder
        end,

        -- 绑定 ViewHolder
        onBindViewHolder = function(holder, position)
          local view = holder.view.getTag()


        end
      }))

      recyclerComments.setAdapter(adapterComments) -- 设置适配器
      recyclerComments.setLayoutManager(GridLayoutManager(activity, #statusBarData)) -- 设置布局管理器
]]
     else
      refreshLayout.refreshing = false

      scrollView.removeAllViews()
      scrollView.addView(loadlayout(import "error/layout"))

      toolbar.setTitle(text_error)
      textCode.Text = tostring(code)

      if code == 404 then
        textError.Text = error_404

       elseif code == -1 then
        if readData("site") == "e621.net" then
          textError.Text = error_e621

         else
          textError.Text = error_no_network

        end

       else
        toolbar.setTitle(text_error)
        textCode.Text = tostring(code)
        textError.Text = texts_error..debugInformation

      end

    end
  end)
end

local appVer = this.getPackageManager().getPackageInfo(this.getPackageName(),0).versionName

initData(url)

-- Toolbar 菜单
--local navigationMenu = toolbar.menu

import "iconDrawable"

--[[navigationMenu.add(0,0,0,text_settings).setIcon(iconDrawable("setting_black_24dp.png")).setShowAsAction(2)

local appName = this.getPackageManager().getApplicationLabel(this.getPackageManager().getApplicationInfo(this.getPackageName(),0))

toolbar.setOnMenuItemClickListener(OnMenuItemClickListener{
  onMenuItemClick=function(item)
    if tostring(item) == text_settings then
--      activity.newActivity("settings")
    end
  end
})]]

toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}