-- 导入所需的包
require "import"
import "requireImports"
import "functions"

-- 设置主题
activity.setTheme(R.style.Theme_ReOpenLua_Material3)

DynamicColors.applyToActivityIfAvailable(this)

local themeUtil = LuaThemeUtil(this)
MDC_R = luajava.bindClass"com.google.android.material.R"
surfaceColor = themeUtil.getColorSurface()
-- 更多颜色分类 请查阅Material.io官方文档
backgroundc = themeUtil.getColorBackground()
surfaceVar = themeUtil.getColorSurfaceVariant()
titleColor = themeUtil.getTitleTextColor()
primaryc = themeUtil.getColorPrimary()
secondary = themeUtil.getColorSecondary()

-- 初始化ripple
rippleRes = TypedValue()
activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, rippleRes, true)

import "lock/layout"

-- 设置布局
activity.setContentView(loadlayout("lock/layout"))
-- 隐藏自带ActionBar
activity.getSupportActionBar().hide()
-- 配置状态栏颜色
local window = activity.getWindow()
if Build.VERSION.SDK_INT >= 21 then
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
  window.setStatusBarColor(Color.TRANSPARENT)
  window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
  window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
 else
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
  window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
end

appbar.getChildAt(0).getLayoutParams().setScrollFlags(0)

toolbar.setNavigationOnClickListener{
  onClick=function()
    activity.finish()
  end
}

local lockTitleData = {
--  text_pin_password,
  text_biometrics
}

-- 创建适配器
adapterLock = LuaCustRecyclerAdapter(AdapterCreator({

  -- 获取数据项数量
  getItemCount = function()
    return #lockTitleData
  end,

  -- 获取数据项视图类型
  getItemViewType = function(position)
    return 0
  end,

  -- 创建 ViewHolder
  onCreateViewHolder = function(parent, viewType)
    local views = {}

    -- 加载布局文件
    holder = LuaCustRecyclerHolder(loadlayout(import "lock/items_card_switch", views))
    holder.view.setTag(views)
    return holder
  end,

  -- 绑定 ViewHolder
  onBindViewHolder = function(holder, position)
    local view = holder.view.getTag()

    view.titleSub.Text = lockTitleData[position + 1]

    if lockTitleData[position + 1] == text_biometrics then
      if isBiometricsSupported() then
        if readData("biometrics") != nil then
          view.switchItems.setChecked(true)
        end

       else
        view.switchItems.setEnabled(false)

      end
    end

    view.switchItems.onClick = function()
      if view.switchItems.isChecked() then
        if lockTitleData[position + 1] == text_biometrics then
          if isBiometricsSupported() then
            saveData("biometrics", "1")
          end

        end

       else
        if lockTitleData[position + 1] == text_biometrics then
          removeData("biometrics")
        end

      end
    end

    view.cardItems.onClick = function()
      if lockTitleData[position + 1] == text_biometrics then
        if isBiometricsSupported() then
         else
          isBiometricsSupported()

          dialog = MaterialAlertDialogBuilder(this)
          .setTitle(text_biometrics)
          .setMessage(biometrics_unsupport_reason)
          .setPositiveButton(text_confirm, function()
            dialog.dismiss()
          end)
          .show()
        end
      end
    end

  end
}))

local alphaAnimation = ObjectAnimator.ofFloat(recyclerMain, "alpha", {0, 1})
alphaAnimation.setDuration(200)
alphaAnimation.setInterpolator(DecelerateInterpolator())
alphaAnimation.setRepeatCount(0.5)
alphaAnimation.setRepeatMode(Animation.REVERSE)
alphaAnimation.start()

recyclerMain.setAdapter(adapterLock) -- 设置适配器
recyclerMain.setLayoutManager(LinearLayoutManager(activity)) -- 设置布局管理器