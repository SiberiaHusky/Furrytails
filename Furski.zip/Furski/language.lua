if Locale.getDefault().getLanguage() == "zh" or Locale.getDefault().getLanguage() == "zh-CN" or Locale.getDefault().getLanguage() == "zh-SG" then
  import "lang/zh_CN"

 elseif Locale.getDefault().getLanguage() == "zh-HK" or Locale.getDefault().getLanguage() == "zh-MO" then
  import "lang/zh_HK"

 elseif Locale.getDefault().getLanguage() == "zh-TW" then
  import "lang/zh_TW"

 else
  import "lang/en_US"

end